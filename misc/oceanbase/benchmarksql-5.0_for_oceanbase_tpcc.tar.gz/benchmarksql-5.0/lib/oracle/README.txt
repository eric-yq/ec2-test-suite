Copy the ojdbc<version>.jar to use with Oracle here, or make
sure that the environment variable ORACLE_HOME is set properly
and the JDBC driver is found at $ORACLE_HOME/lib.
