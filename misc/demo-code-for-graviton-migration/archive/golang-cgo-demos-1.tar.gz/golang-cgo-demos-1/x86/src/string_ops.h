#ifndef STRING_OPS_H
#define STRING_OPS_H

// Function declarations
char* reverse_string(const char* input);
int string_length(const char* input);

#endif // STRING_OPS_H
