#ifndef MATH_OPS_H
#define MATH_OPS_H

// Function declarations
double multiply(double a, double b);
double divide(double a, double b);

#endif // MATH_OPS_H
