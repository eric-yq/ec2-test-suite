package main

/*
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <time.h>

// CGO函数1: 字符串处理
char* reverse_string(char* str) {
    int len = strlen(str);
    char* reversed = (char*)malloc(len + 1);
    for(int i = 0; i < len; i++) {
        reversed[i] = str[len - 1 - i];
    }
    reversed[len] = '\0';
    return reversed;
}

// CGO函数2: 数学计算
double calculate_circle_area(double radius) {
    return M_PI * radius * radius;
}

// CGO函数3: 系统时间操作
long get_current_timestamp() {
    return (long)time(NULL);
}

// 辅助函数：释放内存
void free_memory(void* ptr) {
    free(ptr);
}
*/
import "C"

import (
	"encoding/json"
	"fmt"
	"log"
	"net/http"
	"strconv"
	"unsafe"

	"github.com/gorilla/mux"
)

// Response 结构体用于JSON响应
type Response struct {
	Message string      `json:"message"`
	Data    interface{} `json:"data"`
	Success bool        `json:"success"`
}

// CGO调用1: 字符串反转
func reverseStringCGO(input string) string {
	cStr := C.CString(input)
	defer C.free(unsafe.Pointer(cStr))

	result := C.reverse_string(cStr)
	defer C.free_memory(unsafe.Pointer(result))

	return C.GoString(result)
}

// CGO调用2: 计算圆的面积
func calculateCircleAreaCGO(radius float64) float64 {
	return float64(C.calculate_circle_area(C.double(radius)))
}

// CGO调用3: 获取当前时间戳
func getCurrentTimestampCGO() int64 {
	return int64(C.get_current_timestamp())
}

// HTTP处理函数
func reverseHandler(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "application/json")
	
	text := r.URL.Query().Get("text")
	if text == "" {
		response := Response{
			Message: "请提供text参数",
			Success: false,
		}
		json.NewEncoder(w).Encode(response)
		return
	}

	reversed := reverseStringCGO(text)
	response := Response{
		Message: "字符串反转成功",
		Data: map[string]string{
			"original": text,
			"reversed": reversed,
		},
		Success: true,
	}
	json.NewEncoder(w).Encode(response)
}

func circleAreaHandler(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "application/json")
	
	radiusStr := r.URL.Query().Get("radius")
	if radiusStr == "" {
		response := Response{
			Message: "请提供radius参数",
			Success: false,
		}
		json.NewEncoder(w).Encode(response)
		return
	}

	radius, err := strconv.ParseFloat(radiusStr, 64)
	if err != nil {
		response := Response{
			Message: "radius参数必须是数字",
			Success: false,
		}
		json.NewEncoder(w).Encode(response)
		return
	}

	area := calculateCircleAreaCGO(radius)
	response := Response{
		Message: "圆面积计算成功",
		Data: map[string]float64{
			"radius": radius,
			"area":   area,
		},
		Success: true,
	}
	json.NewEncoder(w).Encode(response)
}

func timestampHandler(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "application/json")
	
	timestamp := getCurrentTimestampCGO()
	response := Response{
		Message: "获取时间戳成功",
		Data: map[string]int64{
			"timestamp": timestamp,
		},
		Success: true,
	}
	json.NewEncoder(w).Encode(response)
}

func healthHandler(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "application/json")
	
	response := Response{
		Message: "服务运行正常",
		Data: map[string]string{
			"status": "healthy",
			"version": "1.0.0",
		},
		Success: true,
	}
	json.NewEncoder(w).Encode(response)
}

func main() {
	// 演示CGO功能
	fmt.Println("=== CGO演示 ===")
	
	// 演示1: 字符串反转
	testStr := "Hello, CGO!"
	reversed := reverseStringCGO(testStr)
	fmt.Printf("原字符串: %s\n", testStr)
	fmt.Printf("反转后: %s\n", reversed)
	
	// 演示2: 圆面积计算
	radius := 5.0
	area := calculateCircleAreaCGO(radius)
	fmt.Printf("半径 %.2f 的圆面积: %.4f\n", radius, area)
	
	// 演示3: 获取时间戳
	timestamp := getCurrentTimestampCGO()
	fmt.Printf("当前时间戳: %d\n", timestamp)
	
	fmt.Println("\n=== 启动HTTP服务器 ===")
	
	// 创建路由
	r := mux.NewRouter()
	
	// API路由
	api := r.PathPrefix("/api/v1").Subrouter()
	api.HandleFunc("/reverse", reverseHandler).Methods("GET")
	api.HandleFunc("/circle-area", circleAreaHandler).Methods("GET")
	api.HandleFunc("/timestamp", timestampHandler).Methods("GET")
	api.HandleFunc("/health", healthHandler).Methods("GET")
	
	// 根路径
	r.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "application/json")
		response := Response{
			Message: "欢迎使用CGO演示API",
			Data: map[string][]string{
				"endpoints": {
					"GET /api/v1/reverse?text=hello",
					"GET /api/v1/circle-area?radius=5.0",
					"GET /api/v1/timestamp",
					"GET /api/v1/health",
				},
			},
			Success: true,
		}
		json.NewEncoder(w).Encode(response)
	})
	
	port := ":8080"
	fmt.Printf("服务器启动在端口 %s\n", port)
	fmt.Println("访问 http://localhost:8080 查看API文档")
	
	log.Fatal(http.ListenAndServe(port, r))
}
