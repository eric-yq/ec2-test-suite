# Golang CGO 演示项目

这是一个演示如何在Golang中使用CGO的项目，包含3个不同的CGO调用示例，并提供HTTP API接口。

## 项目特性

- **CGO集成**: 包含3个不同类型的CGO调用
- **HTTP API**: 基于Gorilla Mux的RESTful API
- **Docker支持**: 完整的Docker构建配置
- **x86架构优化**: 专门针对x86架构构建

## CGO功能演示

### 1. 字符串处理 (C函数: reverse_string)
- 功能: 反转输入的字符串
- C实现: 使用malloc动态分配内存，手动反转字符串

### 2. 数学计算 (C函数: calculate_circle_area)
- 功能: 计算圆的面积
- C实现: 使用math.h库中的M_PI常量

### 3. 系统调用 (C函数: get_current_timestamp)
- 功能: 获取当前Unix时间戳
- C实现: 使用time.h库获取系统时间

## API接口

| 端点 | 方法 | 参数 | 描述 |
|------|------|------|------|
| `/` | GET | - | API文档和端点列表 |
| `/api/v1/health` | GET | - | 健康检查 |
| `/api/v1/reverse` | GET | `text` | 字符串反转 |
| `/api/v1/circle-area` | GET | `radius` | 计算圆面积 |
| `/api/v1/timestamp` | GET | - | 获取时间戳 |

## 快速开始

### 本地运行

```bash
# 1. 确保安装了Go 1.21+和gcc
go version
gcc --version

# 2. 下载依赖
go mod download

# 3. 运行程序
go run main.go
```

### Docker构建和运行

```bash
# 1. 构建镜像
chmod +x build.sh
./build.sh

# 2. 运行容器
docker run --platform linux/amd64 -p 8080:8080 golang-cgo-demo:latest
```

### 测试API

```bash
# 健康检查
curl http://localhost:8080/api/v1/health

# 字符串反转
curl 'http://localhost:8080/api/v1/reverse?text=Hello%20CGO'

# 计算圆面积
curl 'http://localhost:8080/api/v1/circle-area?radius=5.0'

# 获取时间戳
curl http://localhost:8080/api/v1/timestamp

# 查看所有端点
curl http://localhost:8080/
```

## 项目结构

```
golang-cgo-demo/
├── main.go          # 主程序文件，包含CGO调用和HTTP服务器
├── go.mod           # Go模块定义
├── go.sum           # 依赖校验文件
├── Dockerfile       # Docker构建文件
├── build.sh         # 构建脚本
└── README.md        # 项目文档
```

## 技术栈

- **语言**: Go 1.21
- **CGO**: C语言集成
- **HTTP框架**: Gorilla Mux
- **容器**: Docker
- **架构**: x86 (linux/amd64)

## 构建要求

- Go 1.21或更高版本
- GCC编译器
- Docker (用于容器化)
- Linux x86_64环境

## 注意事项

1. **CGO启用**: 项目需要CGO_ENABLED=1
2. **内存管理**: C代码中的内存分配需要手动释放
3. **架构限制**: 仅支持x86架构
4. **安全性**: 生产环境中建议使用非root用户运行

## 开发说明

- 所有CGO调用都包含适当的内存管理
- HTTP响应统一使用JSON格式
- 包含完整的错误处理
- 支持健康检查和监控
