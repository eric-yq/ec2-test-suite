#!/bin/bash

# 构建脚本 - 专门针对x86架构

set -e

echo "=== 开始构建CGO Golang应用 ==="

# 设置镜像名称和标签
IMAGE_NAME="golang-cgo-demo"
IMAGE_TAG="latest"
FULL_IMAGE_NAME="${IMAGE_NAME}:${IMAGE_TAG}"

echo "构建镜像: ${FULL_IMAGE_NAME}"
echo "目标架构: linux/amd64 (x86)"

# 构建Docker镜像
docker build \
    --platform linux/amd64 \
    --tag ${FULL_IMAGE_NAME} \
    --file Dockerfile \
    .

echo "=== 构建完成 ==="
echo "镜像名称: ${FULL_IMAGE_NAME}"
echo ""
echo "运行容器:"
echo "docker run --platform linux/amd64 -p 8080:8080 ${FULL_IMAGE_NAME}"
echo ""
echo "测试API:"
echo "curl http://localhost:8080/api/v1/health"
echo "curl 'http://localhost:8080/api/v1/reverse?text=hello'"
echo "curl 'http://localhost:8080/api/v1/circle-area?radius=5.0'"
echo "curl http://localhost:8080/api/v1/timestamp"
